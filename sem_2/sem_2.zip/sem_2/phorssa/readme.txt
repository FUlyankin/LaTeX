Thank you for downloading this font. 
~junkohanhero free fonts are free to use in your designs, commercial or non commercial. While they are free, they are not in the public domain and remain in the exclusive property of junkohanhero.
This typeface may not be sold.
		

I like to see what you are doing with my fonts. Please email PDFs, files, screen grabs, digital photos or greetings to: jungobungo@gmail.com 

http://www.junkohanhero.com
http://www.juhakorhonen.com
"N�ihin kuviin, n�ihin tunnelmiin."


