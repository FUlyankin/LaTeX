# Load the necessary packages
library(brew)
library(tools)
library(knitr)


# Function to write report
# Note that since I used "x" in my template I need to use
# "x" as my input in create.report.
create.report <- function(x, prepend = "MyFile_"){
  rnw.file <- paste0(prepend, x, ".Rnw")
  # This generates the actual rnw file for different seeds
  brew('template.Rnw', rnw.file)
  knit(rnw.file)
  latex.file <- paste0(prepend, x, ".tex")
  texi2pdf(latex.file, clean = TRUE, quiet = TRUE)
  out.file <- paste0(prepend, x, ".pdf")
  return(out.file)
}

# This is the input that will change in each report
seeds <- c(1, 2, 3)
# This is us generating the reports!
results <- sapply(seeds, create.report)



file.remove()

