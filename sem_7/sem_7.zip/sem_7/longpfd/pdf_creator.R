# Это PDF-creator! Главная часть нашего документа!
# Подгружаем важные пакеты
library(brew)
library(tools)
library(knitr)


# Запоминаем шапочку :)
fileName <- "head.Rnw"
head <- file(fileName,open="r")
st_head <- readLines(head)
close(head)


# Запоминаем носочки :)
fileName <- "socks.Rnw"
socks <- file(fileName,open="r")
st_socks <- readLines(socks)
close(socks)


# Осталось запомнить кучу одинаковых тел
# Будем создавать по отдельности кучу rnw отчётов, а после
# соединим их в единое целое с шапочкой и носочками

# Функция, которая для каждого 'x' создаёт по шаблону body.Rnw свою анкету

create.anketa <- function(x, prepend = "Anketa_"){
  rnw.file <- paste0(prepend,x,".Rnw")
  brew('body.Rnw',rnw.file)
}


# Объединим всё это чудо в цельный документ! 
people <- c(1, 2, 3) 

Main_pdf <- st_head
for(i in 1:length(people)){
  create.anketa(i)
  fileName <- paste0('Anketa_',as.character(i),'.Rnw')
  ank <- file(fileName,open='r')
  st_ank <- readLines(ank)
  close(ank)
  Main_pdf <- append(Main_pdf,st_ank)
}

# Не забываем добавить носочки! С шапочкой, но без носочков жизнь совсем не та!
Main_pdf <- append(Main_pdf,st_socks)

# Записываем всё это дело в один большой rnw-файлик! 
main <- file('main.Rnw',open='w')
writeLines(Main_pdf,main)
close(main)

# Осталось собрать итоговый файл в одно целое и почистить папку от мусора!
# Делай раз! Собираем!

knit("main.Rnw")                                  # связываем tex-файл через knitr!
texi2pdf("main.tex", clean = TRUE, quiet = TRUE)  # собираем pdf и подчищаем за собой!

# Делай два! Удаляем весь хлам, кроме итогового файла и четырёх базовых!
file.remove("main.tex")
ankets <- paste0("Anketa_",1:length(people),".Rnw")
file.remove(ankets)








